make all 2>&1 && ./Axis.out /home/ubuntu/Test1.png
