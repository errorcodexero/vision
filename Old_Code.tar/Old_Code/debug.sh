make debug
gdb ./Axis_Debug.out
