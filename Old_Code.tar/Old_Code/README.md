Just the code for our vision system
